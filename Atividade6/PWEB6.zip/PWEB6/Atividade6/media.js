const nomeAluno = prompt("Digite o nome do aluno:");
const nota1Str = prompt("Digite a primeira nota:");
const nota2Str = prompt("Digite a segunda nota:");
const nota3Str = prompt("Digite a terceira nota:");
const nota4Str = prompt("Digite a quarta nota:");

const nota1 = parseFloat(nota1Str);
const nota2 = parseFloat(nota2Str);
const nota3 = parseFloat(nota3Str);
const nota4 = parseFloat(nota4Str);

if (isNaN(nota1) || isNaN(nota2) || isNaN(nota3) || isNaN(nota4)) {
    alert("Erro: Por favor, digite apenas números válidos para as notas.");
} else {
    const media = (nota1 + nota2 + nota3 + nota4) / 4;
    alert(`Olá, ${nomeAluno}!\nA sua média é: ${media.toFixed(2)}`);
}