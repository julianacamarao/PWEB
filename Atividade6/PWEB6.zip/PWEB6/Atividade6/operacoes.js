const num1Str = prompt("Digite o primeiro número:");
const num2Str = prompt("Digite o segundo número:");

const num1 = parseFloat(num1Str);
const num2 = parseFloat(num2Str);

if (isNaN(num1) || isNaN(num2)) {
    alert("Erro: Por favor, digite apenas números válidos.");
} else {
    const soma = num1 + num2;
    const subtracao = num1 - num2;
    const produto = num1 * num2;
    let divisao = (num2 !== 0) ? (num1 / num2) : "Impossível dividir por zero";
    let resto = (num2 !== 0) ? (num1 % num2) : "Não aplicável";

    const mensagemResultado = `Resultados para os números ${num1} e ${num2}:
    \n✓ Soma: ${soma}
    \n✓ Subtração: ${subtracao}
    \n✓ Produto: ${produto}
    \n✓ Divisão: ${divisao}
    \n✓ Resto: ${resto}`;

    alert(mensagemResultado);
}